﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Xrm.Tooling.Connector;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;

namespace Carl.Dynamics365CRUD
{
    class Program
    {
        

        static void Main(string[] args)
        {
            try
            {
                var connectionString = @"AuthType = Office365; Url = https://orgecdc10fc.api.crm8.dynamics.com/XRMServices/2011/Organization.svc/;Username=GaneshGunjal@actiboostengineers.onmicrosoft.com;Password=Xyz@#1258";
                CrmServiceClient conn = new CrmServiceClient(connectionString);

                IOrganizationService service;
                service = (IOrganizationService)conn.OrganizationWebProxyClient != null ? (IOrganizationService)conn.OrganizationWebProxyClient : (IOrganizationService)conn.OrganizationServiceProxy;

                //Create a new record
                Entity COURCE = new Entity("COURCE");
                COURCE["new_name"] = "COMPUTER";
               
                Guid new_courceid = service.Create(COURCE);
                Console.WriteLine("New courceid: {0}.", new_courceid.ToString());


                // Retrieve a record using Id
                Entity retrievedcource = service.Retrieve(COURCE.LogicalName, new_courceid, new ColumnSet(true));
                Console.WriteLine("Record retrieved {0}", retrievedcource.Id.ToString());

                // Update record using Id, retrieve all attributes
                Entity updatedcource = new Entity("COURCE");
                updatedcource = service.Retrieve(COURCE.LogicalName, new_courceid, new ColumnSet(true));
                updatedcource["Name"] = "Math";

                service.Update(updatedcource);
                Console.WriteLine("Updated cource");




                // Delete a record using Id
                service.Delete(COURCE.LogicalName, new_courceid);
                Console.WriteLine("Deleted");
                Console.ReadLine();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
        }
    }
    }