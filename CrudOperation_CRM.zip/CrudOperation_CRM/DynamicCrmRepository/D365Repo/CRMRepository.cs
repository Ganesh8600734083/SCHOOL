

using Crud_Operation_CRM.Model;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using UoPeople.NGPortal.Service.Repository.MSDynamics.Connection;
using UoPeople.NGPortal.Service.Settings;
using UoPeople.NGPortal.Utility;

namespace UoPeople.NGPortal.Service.Repository.MSDynamics
{
    public class CRMRepository : ICRMRepository
    {
        private readonly IDynamicsConnectionManager connectionManager;
        private Int16 newPADurationInDays;
        public CRMRepository(IConfiguration configuration, IDynamicsConnectionManager _crmConnManager)
        {
            var appConfig = configuration.GetSection(nameof(ApplicationConfig)).Get<ApplicationConfig>();
            newPADurationInDays = appConfig.NewPADurationInDays;
            connectionManager = _crmConnManager;
        }
        public async Task<Acoount> getAccount(string studentID)
        {


            // Create query expression
            //account
            QueryExpression query = new QueryExpression("account");
            query.ColumnSet = new ColumnSet("name", "new_paymentstyle", "new_age");
            Acoount accounts = new Acoount();
            EntityCollection results = await connectionManager.getConnection().RetrieveMultipleAsync(query);
            Entity result = results.Entities.FirstOrDefault();
            if (results != null)
            {
                accounts.name = result.GetAttributeValue<string>("name");
                accounts.paymentstyle = result.GetAttributeValue<string>("new_paymentstyle");
                accounts.age = result.GetAttributeValue<int>("new_age");

            }
            if (results != null)
            {
                accounts.name = result.GetAttributeValue<string>("name");
                accounts.paymentstyle = result.GetAttributeValue<string>("new_paymentstyle");
                accounts.age = result.GetAttributeValue<int>("new_age");
            }
            return accounts;
        }
            public async Task<string> InsertRecordInAccount(string studentID)
        {

            QueryExpression query = new QueryExpression("account");

            
            query.ColumnSet = new ColumnSet("name",  "new_paymentstyle", "new_studentstatus");

           
            query.Criteria.AddCondition("accountid", ConditionOperator.Equal, studentID);

            EntityCollection firstItem = await connectionManager.getConnection().RetrieveMultipleAsync(query);

            if (firstItem != null)
            {
                Entity result = firstItem.Entities.FirstOrDefault();
                var Name = result.GetAttributeValue<string>("name");
                var Status = result.GetAttributeValue<string>("new_studentstatus");
                var mystudent = new Entity("new_studentlatestupdate");
                mystudent.Attributes["new_name"] = Name + " " + Status;
                Guid RecordID = connectionManager.getConnection().Create(mystudent);

                return Name + " " + Status + " record added successfully.StudenID = " + RecordID;
            }
            else{
                return "No record found";
            }
            
        }

        public async Task<string> UpdateRecordInAccount(string studentID)
        {

            // Define the query expression
            QueryExpression query = new QueryExpression("new_studentlatestupdate");

            // Add the columns to retrieve
            query.ColumnSet = new ColumnSet("name");

            // Add the filter criteria
            query.Criteria.AddCondition("new_studentlatestupdateid", ConditionOperator.Equal, studentID);

            EntityCollection firstItem = await connectionManager.getConnection().RetrieveMultipleAsync(query);

            if (firstItem != null)
            {
                Entity result = firstItem.Entities.FirstOrDefault();
                var Name = result.GetAttributeValue<string>("name");
                var mystudent = new Entity("new_studentlatestupdate");
                mystudent.Id = new Guid(studentID);
                mystudent.Attributes["new_name"] = Name + " Edited";
                connectionManager.getConnection().Update(mystudent);
                return Name + " record updated successfully.";
            }
            else
            {
                return "No record found";
            }

        }

        public async Task<string> DeleteRecordInAccount(string studentID)
        {

            // Define the query expression
            QueryExpression query = new QueryExpression("new_studentlatestupdate");

            // Add the columns to retrieve
            query.ColumnSet = new ColumnSet("name");

            // Add the filter criteria
            query.Criteria.AddCondition("new_studentlatestupdateid", ConditionOperator.Equal, studentID);

            EntityCollection firstItem = await connectionManager.getConnection().RetrieveMultipleAsync(query);

            if (firstItem != null)
            {
                Entity result = firstItem.Entities.FirstOrDefault();
                var Name = result.GetAttributeValue<string>("name");
                Guid RecordID = new Guid(studentID);
                connectionManager.getConnection().Delete("new_studentlatestupdate", RecordID);
                return Name + " record deleted successfully.";
            }
            else
            {
                return "No record found";
            }

        }

        
    }
}
