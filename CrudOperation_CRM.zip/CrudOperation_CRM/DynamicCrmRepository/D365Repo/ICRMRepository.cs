

using Crud_Operation_CRM.Model;

namespace UoPeople.NGPortal.Service.Repository.MSDynamics
{
    public interface ICRMRepository
    {
        Task<Acoount> getAccount(string studentID);
        Task<string> InsertRecordInAccount(string studentID);
        Task<string> UpdateRecordInAccount(string studentID);
        Task<string> DeleteRecordInAccount(string studentID);


    }
}