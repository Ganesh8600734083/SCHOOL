﻿namespace Crud_Operation_CRM.Model
{
    public class studentlatestupdate
    {
        public Guid studentStatusUpdateID { get; set; }
        public string studentStatus { get; set; }
        public string name { get; set; }
        public string program { get; set; }

    }
}
