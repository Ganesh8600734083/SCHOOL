﻿namespace Crud_Operation_CRM.Model
{
    public class Acoount
    {
        public Guid studentID { get; set; }
        public string name { get; set; }
        public string paymentstyle { get; set; }
        public int age { get; set; }
        public string Country { get; set; }
        public string Degree { get; set; }
        public string Language { get; set; }
    }
}

