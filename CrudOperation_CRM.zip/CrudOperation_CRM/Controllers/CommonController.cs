

using System.ComponentModel.DataAnnotations;
using Crud_Operation_CRM.Model;
using Microsoft.AspNetCore.Mvc;
using UoPeople.NGPortal.Service.Repository.MSDynamics;
using UoPeople.NGPortal.Service.Repository.MSDynamics.Connection;

namespace UoPeople.NGPortal.Service.Controllers
{
    [ApiController]
    public class CommonController : ControllerBase
    {

        private readonly ICRMRepository portalService;

        public CommonController(ICRMRepository portalService)
        {
            this.portalService = portalService;
        }
        [HttpGet]
        [Route("/common/{studentID}/account")]
        public async Task<ActionResult<Acoount>> account([FromRoute] string studentID)
        {
            Acoount accounts = await portalService.getAccount(studentID);
            return Ok(accounts);
        }

        [HttpGet]
        [Route("/common/{studentID}/InsertRecordInAccount")] 
        public async Task<ActionResult<string>> InsertRecordInAccount([FromRoute][Required] string studentID)
        {
            string notifeData = await portalService.InsertRecordInAccount(studentID);
            return Ok(notifeData);
        }

        [HttpGet]
        [Route("/common/{studentID}/UpdateRecordInAccount")]
        public async Task<ActionResult<string>> UpdateStu([FromRoute][Required] string studentID)
        {
            string notifeData = await portalService.UpdateRecordInAccount(studentID);
            return Ok(notifeData);
        }

        [HttpGet]
        [Route("/common/{studentID}/DeleteRecordInAccount")]
        public async Task<ActionResult<string>> DeleteStudent([FromRoute][Required] string studentID)
        {
            string notifeData = await portalService.DeleteRecordInAccount(studentID);
            return Ok(notifeData);
        }
    }
}